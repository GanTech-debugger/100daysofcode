document.getElementById("link-nacional").disabled = true;
document.getElementById("link-internacional").disabled = true;

